from flask import Flask, request, render_template, url_for
import numpy as np
import pickle
import os

# Initialize Flask app
app = Flask(__name__)

# Load the trained model
model = pickle.load(open('model.pkl', 'rb'))

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route for making predictions
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Extract input features from the form
        nitrogen = float(request.form['nitrogen'])
        phosphorus = float(request.form['phosphorus'])
        potassium = float(request.form['potassium'])
        temperature = float(request.form['temperature'])
        humidity = float(request.form['humidity'])
        ph = float(request.form['ph'])
        rainfall = float(request.form['rainfall'])

        # Convert features into a numpy array for model prediction
        features = np.array([[nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall]])

        # Make a prediction
        prediction = model.predict(features)[0]  # Assuming the prediction returns "rice"

        # Get the image filename corresponding to the predicted crop (in this case, rice)
        image_filename = f"{prediction}.png"
        print(image_filename)# This becomes 'rice.jpg' if prediction is 'rice'

        # Check if the image file exists in the static/images folder
        image_path = os.path.join('static/images', image_filename)
        if not os.path.exists(image_path):
            image_filename = "default.png"  # Fallback image if not found

        # Pass the prediction and image filename to the template
        return render_template('index.html', prediction_text=f'Suggested Crop: {prediction}', crop_image=image_filename)

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
